import 'package:flutter/material.dart';

const String google_api_key = "AIzaSyCWz3E6yH8JaYJ0y-LBYmHSRZsQZLUFqdM";
const Color primaryColor = Color.fromARGB(255, 177, 127, 52);
const double defaultPadding = 16.0;
